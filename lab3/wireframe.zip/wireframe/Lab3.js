var FSIZE = 4; // size of a vertex coordinate (32-bit float)
var VSHADER_SOURCE = null; // vertex shader program
var FSHADER_SOURCE = null; // fragment shader program

var g_points = []; // array of mouse presses
var open = false
var numSides = 14
var radius = 0.1
var volume = 0
var surfaceArea = 0
var cylinderInd = 0

var l = [1,1,1]
var icol = [1,1,1]

var first1 = true
var first2 = true
var draw = false

function main() {
    // retrieve <canvas> element
    var canvas = document.getElementById('webgl');
    // get the rendering context for WebGL
    var gl = getWebGLContext(canvas);
    if (!gl) {
        console.log('Failed to get the rendering context for WebGL');
        return;
    }
    // load shader files
    loadFile("shader.vert", function(shader_src) { setShader(gl, canvas, gl.VERTEX_SHADER, shader_src); });
    loadFile("shader.frag", function(shader_src) { setShader(gl, canvas, gl.FRAGMENT_SHADER, shader_src); });
}

function setShader(gl, canvas, shader, shader_src) {
    if (shader == gl.VERTEX_SHADER)
        VSHADER_SOURCE = shader_src;
    if (shader == gl.FRAGMENT_SHADER)
        FSHADER_SOURCE = shader_src;
    if (VSHADER_SOURCE && FSHADER_SOURCE)
        start(gl, canvas);
}

function start(gl, canvas) {
    // initialize shaders
    if (!initShaders(gl, VSHADER_SOURCE, FSHADER_SOURCE)) {
        console.log('Failed to intialize shaders.');
        return;
    }
    // initialize buffers
    var success = initVertexBuffer(gl);
    success = success && initIndexBuffer(gl);
    success = success && initAttributes(gl);
    if (!success) {
        console.log('Failed to initialize buffers.');
        return;
    }
    // specify the color for clearing <canvas>
    gl.clearColor(0, 0, 0, 1);
    // clear <canvas>
    gl.clear(gl.COLOR_BUFFER_BIT);

    // draw a polygon wireframe (red)
    //drawPolygonWireframe(gl, 9, 0.3, -0.5, -0.3, 1, 0, 0, 1);
    // draw a polygon filled in using TRIANGLES (uses drawElements) (green)
    //drawPolygonTriangles1(gl, 9, 0.3, 0.5, -0.3, 0, 1, 0, 1);
    // draw a polygon filled in using TRIANGLES (uses drawArrays) (blue)
    //drawPolygonTriangles2(gl, 9, 0.3, 0, 0.3, 0, 0, 1, 1);
   document.getElementById('shift').onclick = function(){ shiftCylinder(canvas, gl); };
   canvas.onmousedown = function(ev){ click(ev, gl, canvas); };
   canvas.onmousemove = function(ev){ move(ev, gl, canvas) }
}


function shiftCylinder(canvas, gl){
   console.log(g_points)
   var i = 0
   for(i = 0; i+6 < g_points.length; i+=7){
     g_points[i] += 0.01
   }
   drawCylinderLines(gl)
}
//var ind = [0,1,2,
//           3,0,2]

// var v1 = [x,y,z]
// var v2 = [a,b,c]
// v1 x v2 = (yc-zb, -(xc-za), (xb-ya))

//P0, P1, P2, P3
//P0, P1, P2
//(P1-P0) (P2-P0)
function drawNormal(vertices, gl) {
  var i = 0
  var point = 1
  var points = []
  for(i = 0; i+6 < vertices.length; i+=7){
    var point = {x:0, y:0, z:0}
    var j = 0
    point.x = vertices[i]
    point.y = vertices[i+1]
    point.z = vertices[i+2]
    points.push(point)
    point++
  }
  var v1 = [points[1].x - points[0].x, points[1].y - points[0].y, points[1].z - points[0].z]
  var v2 = [points[2].x - points[0].x, points[2].y - points[0].y, points[2].z - points[0].z]
  var n = [(v1[1]*v2[2] - v1[2]*v2[1]), -(v1[0]*v2[2] - v1[2]*v2[0]), (v1[0]*v2[1] - v1[1]*v2[0])]
  var dist = Math.sqrt(Math.pow(n[0], 2) + Math.pow(n[1], 2) + Math.pow(n[2],2))
  n = [n[0]/dist, n[1]/dist, n[2]/dist]
  var ogN = n

  n = [0.15*n[0], 0.15*n[1], 0.15*n[2]]
  //n = [n[0], n[1], n[2]]
  //console.log(n)
  var center = [(points[0].x + points[1].x + points[2].x)/3, (points[0].y + points[1].y + points[2].y)/3, (points[0].z + points[1].z + points[2].z)/3]
  var ray = [center[0]+n[0], center[1]+n[1], center[2]+n[2]]
  //var aprime = -(ray[0] - center[0])
  //var bprime = (ray[1] - center[1])
  //ray = [ray[0] - bprime, ray[1]- aprime, ray[2]]
  var color = [1, 0, 0, 1]
  var vertices = []
  i = 0
  for(i = 0; i < center.length; i++)
    vertices.push(center[i])
  for(i = 0; i < color.length; i++)
    vertices.push(color[i])
  for(i = 0; i < ray.length; i++)
    vertices.push(ray[i])
  for(i = 0; i < color.length; i++)
    vertices.push(color[i])
  var ind = [0,1]
  setVertexBuffer(gl, new Float32Array(vertices));
  setIndexBuffer(gl, new Uint16Array(ind));
  gl.drawElements(gl.LINES, ind.length, gl.UNSIGNED_SHORT, 0)
  return ogN
}

// initialize vertex buffer
function initVertexBuffer(gl) {
    // create buffer object
    var vertex_buffer = gl.createBuffer();
    if (!vertex_buffer) {
        console.log("failed to create vertex buffer");
        return false;
    }
    // bind buffer objects to targets
    gl.bindBuffer(gl.ARRAY_BUFFER, vertex_buffer);
    return true;
}

// initialize index buffer
function initIndexBuffer(gl) {
    // create buffer object
    var index_buffer = gl.createBuffer();
    if (!index_buffer) {
        console.log("failed to create index buffer");
        return false;
    }
    // bind buffer objects to targets
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, index_buffer);
    return true;
}

// set data in vertex buffer (given typed float32 array)
function setVertexBuffer(gl, vertices) {
    gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);
}

// set data in index buffer (given typed uint16 array)
function setIndexBuffer(gl, indices) {
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, indices, gl.STATIC_DRAW);
}

// initializes attributes
function initAttributes(gl) {
    // assign buffers and enable assignment
    var a_Position = gl.getAttribLocation(gl.program, 'a_Position');
    var a_Color = gl.getAttribLocation(gl.program, 'a_Color');
    if (a_Position < 0) {
        console.log("failed to get storage location of a_Position");
        return false;
    }
    gl.vertexAttribPointer(a_Position, 3, gl.FLOAT, false, FSIZE * 7, 0);
    gl.enableVertexAttribArray(a_Position);
    gl.vertexAttribPointer(a_Color, 4, gl.FLOAT, false, FSIZE * 7, FSIZE * 3);
    gl.enableVertexAttribArray(a_Color);
    return true;
}

// Called when user clicks on canvas
function click(ev, gl, canvas) {
    open = true
    move(ev,gl,canvas)
    var x = ev.clientX; // x coordinate of a mouse pointer
    var y = ev.clientY; // y coordinate of a mouse pointer
    var rect = ev.target.getBoundingClientRect();
    x = ((x - rect.left) - canvas.width/2)/(canvas.width/2);
    y = (canvas.height/2 - (y - rect.top))/(canvas.height/2);
    // Store the vertex information to g_points array
    g_points.push(x); // x-coordinate
    g_points.push(y); // y-coordinate
    g_points.push(0); // z-coordinate is 0; polyline lines in xy-plane z=0
    g_points.push(0);
    g_points.push(1);
    g_points.push(0);
    g_points.push(1);

    // Clear canvas
    gl.clear(gl.COLOR_BUFFER_BIT);
    // Draw polyline
    drawPolyline(gl);

    // If user right clicks, finish polyline and draw cylinder
    if (ev.button == 2) {
      gl.clear(gl.COLOR_BUFFER_BIT);
      open = false
      drawCylinderLines(gl)
	   canvas.onmousedown = null;
    }
}

function move(ev, gl, canvas) {
    if(!open)
      return
    var x = ev.clientX; // x coordinate of a mouse pointer
    var y = ev.clientY; // y coordinate of a mouse pointer
    var rect = ev.target.getBoundingClientRect();
    x = ((x - rect.left) - canvas.width/2)/(canvas.width/2);
    y = (canvas.height/2 - (y - rect.top))/(canvas.height/2);
    // Store the vertex information to g_points array
    g_points = g_points.splice(0,g_points.length-7)
    g_points.push(x); // x-coordinate
    g_points.push(y); // y-coordinate
    g_points.push(0); // z-coordinate is 0; polyline lines in xy-plane z=0
    g_points.push(0);
    g_points.push(1);
    g_points.push(0);
    g_points.push(1);

    // Clear canvas
    gl.clear(gl.COLOR_BUFFER_BIT);
    // Draw polyline
    drawPolyline(gl);

    // If user right clicks, finish polyline and draw cylinder
    if (ev.button == 2) {
	// Clear canvas
	gl.clear(gl.COLOR_BUFFER_BIT);
	/* PUT CODE TO GENERATE VERTICES/INDICES OF CYLINDER AND DRAW HERE */
	//drawRectangles(gl); // EXAMPLE: Generates rectangles whose corners are connected
	// drawPolyline(gl); // EXAMPLE: Draw polyline
	// Remove click handle
	canvas.onmousedown = null;
    }
}

function drawPolyline(gl) {
    // Set vertices
    setVertexBuffer(gl, new Float32Array(g_points));
    var n = Math.floor(g_points.length/7);
    // Set indices (just an array of the numbers 0 to (n-1), which connects them one by one)
    var ind = [];
    for (i = 0; i < n; ++i)
	    ind.push(i);
    setIndexBuffer(gl, new Uint16Array(ind));
    // Draw points and lines
    //gl.drawElements(gl.POINTS, n, gl.UNSIGNED_SHORT, 0);
    gl.drawElements(gl.LINE_STRIP, n, gl.UNSIGNED_SHORT, 0);
}

function drawPolygonWireframe(gl, n, rad, c_x, c_y, r, g, b, a) {
    var vert = []; // vertex array
    var ind = []; // index array
    // angle (in radians) between sides
    var angle = (2 * Math.PI) / n;
    // create triangles
    for (var i = 0; i < n; i++) {
        // calculate the vertex locations
        var x1 = (rad * Math.cos(angle * i)) + c_x;
        var y1 = (rad * Math.sin(angle * i)) + c_y;
        var x2 = (rad * Math.cos(angle * (i + 1))) + c_x;
        var y2 = (rad * Math.sin(angle * (i + 1))) + c_y;
        // calculate the per-surface color (all vertices on the same surface have the same color for Assignment 3)
        // for assignment 3, you will need to calculate surface normals.
        // in this example, we will shade based on position (namely, the average of the corners of the triangle)
        var col = shadeRightwards((c_x + x1 + x2)/2, (c_y + y1 + y2)/3, r, g, b, a);
        // center vertex
        vert.push(c_x);
        vert.push(c_y);
        vert.push(0);
        vert.push(col[0]);
        vert.push(col[1]);
        vert.push(col[2]);
        vert.push(col[3]);
        // first outer vertex
        vert.push(x1);
        vert.push(y1);
        vert.push(0);
        vert.push(col[0]);
        vert.push(col[1]);
        vert.push(col[2]);
        vert.push(col[3]);
        // second outer vertex
        vert.push(x2);
        vert.push(y2);
        vert.push(0);
        vert.push(col[0]);
        vert.push(col[1]);
        vert.push(col[2]);
        vert.push(col[3]);
        // connect vertices
        ind.push(i * 3); // start at center
        ind.push((i * 3) + 1); // go to first outer vertex
        ind.push((i * 3) + 2); // go to second outer vertex
        ind.push(i * 3); // go back to center
    }
    // set buffers
    setVertexBuffer(gl, new Float32Array(vert));
    setIndexBuffer(gl, new Uint16Array(ind));
    // draw polygon
    gl.drawElements(gl.LINE_STRIP, ind.length, gl.UNSIGNED_SHORT, 0);
}

function drawPolygonTriangles1(gl, n, rad, c_x, c_y, r, g, b, a) {
    var vert = []; // vertex array
    var ind = []; // index array
    // angle (in radians) between sides
    var angle = (2 * Math.PI) / n;
    // create triangles
    for (var i = 0; i < n; i++) {
        // calculate the vertex locations
        var x1 = (rad * Math.cos(angle * i)) + c_x;
        var y1 = (rad * Math.sin(angle * i)) + c_y;
        var x2 = (rad * Math.cos(angle * (i + 1))) + c_x;
        var y2 = (rad * Math.sin(angle * (i + 1))) + c_y;
        // calculate the per-surface color (all vertices on the same surface have the same color for Assignment 3)
        // for assignment 3, you will need to calculate surface normals.
        // in this example, we will shade based on position (namely, the average of the corners of the triangle)
        var col = shadeRightwards((c_x + x1 + x2)/2, (c_y + y1 + y2)/3, r, g, b, a);
        // center vertex
        vert.push(c_x);
        vert.push(c_y);
        vert.push(0);
        vert.push(col[0]);
        vert.push(col[1]);
        vert.push(col[2]);
        vert.push(col[3]);
        // first outer vertex
        vert.push(x1);
        vert.push(y1);
        vert.push(0);
        vert.push(col[0]);
        vert.push(col[1]);
        vert.push(col[2]);
        vert.push(col[3]);
        // second outer vertex
        vert.push(x2);
        vert.push(y2);
        vert.push(0);
        vert.push(col[0]);
        vert.push(col[1]);
        vert.push(col[2]);
        vert.push(col[3]);
        // connect vertices
        ind.push(i * 3); // start at center
        ind.push((i * 3) + 1); // go to first outer vertex
        ind.push((i * 3) + 2); // go to second outer vertex
    }
    // set buffers
    setVertexBuffer(gl, new Float32Array(vert));
    setIndexBuffer(gl, new Uint16Array(ind));
    // draw polygon
    gl.drawElements(gl.TRIANGLES, ind.length, gl.UNSIGNED_SHORT, 0);
}

function drawPolygonTriangles2(gl, n, rad, c_x, c_y, r, g, b, a) {
    var vert = []; // vertex array
    // angle (in radians) between sides
    var angle = (2 * Math.PI) / n;
    // create triangles
    for (var i = 0; i < n; i++) {
                // calculate the vertex locations
        var x1 = (rad * Math.cos(angle * i)) + c_x;
        var y1 = (rad * Math.sin(angle * i)) + c_y;
        var x2 = (rad * Math.cos(angle * (i + 1))) + c_x;
        var y2 = (rad * Math.sin(angle * (i + 1))) + c_y;
        // calculate the per-surface color (all vertices on the same surface have the same color for Assignment 3)
        // for assignment 3, you will need to calculate surface normals.
        // in this example, we will shade based on position (namely, the average of the corners of the triangle)
        var col = shadeRightwards((c_x + x1 + x2)/2, (c_y + y1 + y2)/3, r, g, b, a);
        // center vertex
        vert.push(c_x);
        vert.push(c_y);
        vert.push(0);
        vert.push(col[0]);
        vert.push(col[1]);
        vert.push(col[2]);
        vert.push(col[3]);
        // first outer vertex
        vert.push(x1);
        vert.push(y1);
        vert.push(0);
        vert.push(col[0]);
        vert.push(col[1]);
        vert.push(col[2]);
        vert.push(col[3]);
        // second outer vertex
        vert.push(x2);
        vert.push(y2);
        vert.push(0);
        vert.push(col[0]);
        vert.push(col[1]);
        vert.push(col[2]);
        vert.push(col[3]);
    }
    // set buffers
    setVertexBuffer(gl, new Float32Array(vert));
    // draw polygon
    gl.drawArrays(gl.TRIANGLES, 0, vert.length/7);
}

function shadeRightwards(arr) {
    var x = arr[0]
    var y = arr[1]
    var z = arr[2]
    var r = arr[3]
    var g = arr[4]
    var b = arr[5]
    var a = arr[6]
    //var col = [r, g, b, a]; // shaded color
    //var ratio = (1 - ((x + 1) / 2)); // measure of how far right (normalized)
    //for (j = 0; j < 3; j++)
    //    col[j] = col[j] * ratio;
    var col = [0, 1, 0, 1]
    return col;
}

/// CYLINDER CODE
function drawCylinderLines(gl){
  gl.clear(gl.COLOR_BUFFER_BIT);
   var i = 0
   var last = []
   var arr = []
   for(i = 0; i+6 < g_points.length; i+=7){
     arr.push(g_points[i])
     arr.push(g_points[i+1])
   }

   var index = 0
   for(i = 0; i+1 < arr.length; i+=2){
     var point = [arr[i], arr[i+1]]
     if( last.length == 0){
         last.push(arr[i])
         last.push(arr[i+1])
     }
     else {
       index++;
       drawCylinder(last, point, gl, numSides, radius, index)
       last = []
       last = point
     }
   }
}

function drawCylinder(point1, point2, gl, numSides, radius, index){
  var arr = getCirclePoint(point1, numSides, radius)
  var k = 0
  var newArray = []
  for(k = 0; k < 28; k++){
    newArray.push[arr[k]]
  }
  var arr2 = getCirclePoint(point2, numSides, radius)
  var angle = toDegrees(Math.atan((point2[0]-point1[0])/(point2[1]-point1[1])))
  arr = rotatePoint(arr, angle, point1)
  arr2 = rotatePoint(arr2, angle, point2)

  var vertices = new Float32Array(arr)
  var vertices2 = new Float32Array(arr2)

  var indiceArr = []
  var i = 0
  for(i = 0; i < numSides; i++)
    indiceArr.push(i)
  indiceArr.push(0)
  var indices = new Int16Array(indiceArr)

  setIndexBuffer(gl, indices);

  setVertexBuffer(gl, vertices)
  gl.drawElements(gl.LINE_STRIP, indices.length, gl.UNSIGNED_SHORT, 0);

  setVertexBuffer(gl, vertices2)
  gl.drawElements(gl.LINE_STRIP, indices.length, gl.UNSIGNED_SHORT, 0);

  connectSquares(arr, arr2, gl)
  var dist = Math.sqrt(Math.pow((point2[1]-point1[1]),2) + Math.pow((point2[0]-point1[0]),2))
  var tempVol = dist*area(numSides, radius)
  var deg = 360/numSides
  var tempSurfArea = 2*area(numSides, radius) + numSides*dist*(2*radius*Math.sin(toRadians(deg/2)))
  if(tempVol>0){
      cylinderInd++
  }
  volume += tempVol
  surfaceArea += tempSurfArea
}

function area(n, r){
  var deg = 360/n
  var inp = deg/2
  var num = n * r * r * Math.sin(toRadians(inp)) * Math.cos(toRadians(inp))
  return num
}

function getCirclePoint(center, numSides, radius){
  var arr = []
  var degree = 360/numSides
  var i = 0
  for(i = 1; i <= numSides; i++){
    arr.push(radius*Math.cos(toRadians(i*degree))+center[0])
    arr.push(center[1])
    arr.push(radius*Math.sin(toRadians(i*degree)))
    arr.push(0)
    arr.push(1)
    arr.push(0)
    arr.push(1)
  }
  return arr
}

function rotatePoint(arr, deg, point){
  deg = -deg
  if(point.length != 2)
    return
  var a = point[0]
  var b = point[1]
  var rArr = []
  if(arr.length%7 != 0)
    return
  var i = 0
  for(i = 0; i+6 < arr.length; i+=7){
    var x = arr[i]
    var y = arr[i+1]
    rArr.push((x-a)*Math.cos(toRadians(deg)) - (y-b)*Math.sin(toRadians(deg))+a)
    rArr.push((x-a)*Math.sin(toRadians(deg)) + (y-b)*Math.cos(toRadians(deg))+b)
    rArr.push(arr[i+1])
    rArr.push(0)
    rArr.push(1)
    rArr.push(0)
    rArr.push(1)
  }
  return rArr
}

function toRadians (angle) {
  return angle * (Math.PI / 180);
}

function toDegrees (angle) {
  return angle * (180 / Math.PI)
}

function connectSquares(arr, arr2, gl){
  var sqArr = []
  //Add i+0-i+6 of arr, Add i+0-i+13 of arr2, Add i+7-i+13 of arr
  for(i = 0; i+13 < arr.length; i+=14){
    sqArr = []
    var j = 0
    for(j = 0; j<7; j++)
      sqArr.push(arr[i+j])
    for(j = 0; j<14; j++)
      sqArr.push(arr2[i+j])
    for(j = 7; j<14; j++)
      sqArr.push(arr[i+j])
    for(j = 0; j+6 < sqArr.length; j+=7){
      //finalCol = shading(sqArr.splice(j,j+6))
      var n = drawNormal(sqArr, gl)
      var finalCol = []
      var l = 0
      for(l = j; l < j+7; l++)
        finalCol.push(sqArr[l])
      finalCol = shading(n)
      sqArr[j+3] = finalCol[0]
      sqArr[j+4] = finalCol[1]
      sqArr[j+5] = finalCol[2]
      sqArr[j+6] = finalCol[3]
    }
    //var n = drawNormal(sqArr, gl)
    drawSquare(sqArr, gl)
    drawNormal(sqArr, gl)
  }

   //Add i+0-i+2 of arr, then the 4 colors, then add i+0-i+2 of arr2 then the 4 colors
   //                                       then add i+7-i+9 of arr2 then the 4 colors
   //Add i+7-i+9 of arr, then the 4 colors
}

function shading(arr){
  var dotprod = Math.abs(l[0]*arr[0] + l[1]*arr[1] + l[2]*arr[2])
  var col = [0, 1, 0, 1]
  return col
}

function drawSquare(vertices, gl){
  if(vertices.length != 28)
    return
  var i = 0
  var center = [0,0,0]
  for(i = 0; i < 21; i++){
    if(i%7==0)
      center[0] += vertices[i]
    if((i-1)%7==0)
      center[1] += vertices[i]
    if((i-2)%7==0)
      center[2] += vertices[i]
  }
  center = [center[0]/3, center[1]/3, center[2]/3]
  var ind = [0,1,2,
             3,0,2]
  setVertexBuffer(gl, new Float32Array(vertices));
  setIndexBuffer(gl, new Uint16Array(ind));
  gl.drawElements(gl.TRIANGLES, ind.length, gl.UNSIGNED_SHORT, 0);
}
